aerofiy Field — Android App (Salesman & Deliveryman Only)
=========================================================
Live Field URL: https://dms.aerofiy.com/?app=field
Restricted Roles: Sales Representatives & Deliverymen ONLY.

OPTION 1 — Instant Install on Android Phones (Recommended, No APK Build Required)
1. Upload & extract dms-aerofiy-com-cpanel.zip to your https://dms.aerofiy.com cPanel subdomain root.
2. Enable HTTPS (AutoSSL) in cPanel.
3. Have each Salesman or Deliveryman open https://dms.aerofiy.com/?app=field in Chrome on Android,
   or sign in to their portal and tap "Install Android App".
4. Android installs "aerofiyField" directly onto their Home Screen & App Drawer as a standalone app.

OPTION 2 — Build a Signed Android APK (.apk) with Capacitor & Android Studio
Prerequisites: Node.js 18+ and Android Studio installed on your computer.
1. Extract this ZIP (aerofiy-field-android-app.zip) into a folder.
2. Run:
     npm install
     npm run sync:android
     npm run open:android
3. In Android Studio, choose: Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. Share the resulting app-debug.apk or signed app-release.apk with your Salesmen & Deliverymen.
   Note: Add android.permission.ACCESS_FINE_LOCATION and android.permission.CAMERA in
   android/app/src/main/AndroidManifest.xml for GPS store tagging & photo capture.
